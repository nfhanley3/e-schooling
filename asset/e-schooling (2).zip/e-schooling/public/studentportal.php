<?php

echo "<html>\n";
echo "<head>\n";
echo "	<title>Student Portal</title>\n";
echo "<br/>\n";
echo "	<link rel = \"stylesheet\" href=\"studentportal.css\" type=\"text/css\" />\n";
echo "\n";
echo "</head>\n";
echo "\n";
echo "<body>\n";
echo "	<div class = \"header\">\n";
echo "		<img src=\"F:Imagese-schooling_logo.gif\" width=\"195\" height=\"70\"/>\n";
echo "	  </div>\n";
echo "\n";
echo "<form align=\"right\" name=\"form1\" method=\"post\" action=\"log_out.php\">\n";
echo "  <label class=\"logoutLblPos\">\n";
echo "  <input name=\"submit2\" type=\"submit\" id=\"submit2\" value=\"log out\">\n";
echo "  </label>\n";
echo "</form>\n";
echo "\n";
echo "\n";
echo "		<h1><strong>Student Portal</strong></h1>\n";
echo "                    <center><img src=\"F:images1.png\" width=\"150px\" height=\"150\">           <img src=\"F:imagesn13.png\" width=\"150px\" height=\"150\"></center>\n";
echo "		    \n";
echo "\n";
echo "\n";
echo "                   <h2><center>Student                               Calendar</center></h2>\n";
echo "\n";
echo "	<div class = \"footer\">\n";
echo "		<p> © e-Schooling Management Systems <br>\n";
echo "			12345 Post Oak Road,Houston, TX 77054 -(832)555-5521		 <br>\n";
echo "			\n";
echo "		</p>\n";
echo "\n";
echo "	\n";
echo "\n";
echo "	    <h2><image Scr=\"deskimages:1images1\"/></h2>\n";
echo "		<center><image scr=\"images/1.jpg\"</center>\n";
echo "\n";
echo "\n";
echo "</body>\n";
echo "</html>\n";

?>
