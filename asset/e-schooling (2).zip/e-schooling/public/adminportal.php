<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <title>Home Page::Log In</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Main CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="css/adminportal.css">
  
  </head>
  <body>
    <table class="admin_headerlogo">
      <tr>
        <td>
            <a href="#"><img src="../image/e-schooling_logo.gif" width="195px" height="70px"></a>
        </td>
      </tr>
    </table>
    <table class="admin_wrapper">
      <p>Admin Interface</p>
      <tr>
        <td class="p_logo"><img src="../image/students_logo.png">
          <label>Students</label>
        </td>
        <td class="p_logo"><img src="../image/teachers_logo.png">
          <label>Teachers</label>
        </td>
        <td class="p_logo"><img src="../image/calander_logo.png">
          <label>Calendar</label>
        </td>      
      </tr>
    </table>

    <div class="footer">
      
    </div>
  </body>
</html>