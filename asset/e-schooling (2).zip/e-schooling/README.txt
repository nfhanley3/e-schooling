I was able to modify the adminportal.php and the corresponding css. So, Naghmeh and Natasha can you guys go through it and let me know if that's okay or not. 

Secondly, I also noticed that the images has dot borders and but for some reason the person that created those images gave them a solid black borders. Please guys look into this and make any correction that need to be made.
